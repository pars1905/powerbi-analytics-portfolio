#!/usr/bin/env python3
"""
Power BI Analytics Portfolio (.pbip) Otomatik Onarım ve Doğrulama Betiği
Depo: https://github.com/pars1905/powerbi-analytics-portfolio

Bu betik, Windows Power BI Desktop'ta .pbip projelerinin açılışta hata vermesine
neden olan eksik tema dosyalarını (StaticResources/SharedResources/BaseThemes/CY24SU06.json)
oluşturur ve report.json / definition.pbir yapılarını Power BI Desktop ile tam uyumlu hale getirir.

Kullanım:
  1. Bu dosyayı yerel 'powerbi-analytics-portfolio' klasörünüzün kök dizinine kaydedin.
  2. Terminal veya Komut İstemi'nde (CMD / PowerShell) çalıştırın:
     python fix_pbip_projects.py
  3. Ardından her klasördeki <Proje>.pbip dosyasını Power BI Desktop ile açıp
     File > Save As > .pbix olarak kaydedebilirsiniz.
"""

import json
from pathlib import Path

BASE_THEME_CY24SU06 = {
    "name": "CY24SU06",
    "dataColors": [
        "#118DFF", "#12239E", "#E66C37", "#6B007B",
        "#E044A7", "#744EC2", "#D9B300", "#D64550",
        "#197278", "#1AAB40", "#15C6F4", "#4092FF"
    ],
    "background": "#FFFFFF",
    "foreground": "#252423",
    "tableAccent": "#118DFF"
}

PROJECTS = [
    "01_Makro",
    "02_Ecommerce",
    "03_RFM",
    "04_SQL_Buyume",
    "05_SQL_Retention",
    "06_SQL_Sepet",
    "07_AB_Donusum",
    "08_AB_Gelir",
    "09_AB_CUPED",
    "10_Risk_German",
    "11_Risk_Taiwan",
    "12_Risk_Politika",
]


def fix_project(root_dir: Path, project_name: str) -> bool:
    proj_dir = root_dir / project_name
    if not proj_dir.exists():
        print(f"[ATLANDI] {project_name} klasörü bulunamadı: {proj_dir}")
        return False

    report_dir = proj_dir / f"{project_name}.Report"
    if not report_dir.exists():
        print(f"[HATA] {report_dir} bulunamadı.")
        return False

    # 1. Eksik olan StaticResources/SharedResources/BaseThemes/CY24SU06.json dosyasını oluştur
    theme_dir = report_dir / "StaticResources" / "SharedResources" / "BaseThemes"
    theme_dir.mkdir(parents=True, exist_ok=True)
    theme_file = theme_dir / "CY24SU06.json"
    theme_file.write_text(
        json.dumps(BASE_THEME_CY24SU06, indent=2, ensure_ascii=False),
        encoding="utf-8"
    )

    # 2. report.json dosyasını kontrol et ve resourcePackages referansını doğrula
    report_json_path = report_dir / "report.json"
    if report_json_path.exists():
        data = json.loads(report_json_path.read_text(encoding="utf-8"))
        # Eğer resourcePackages içinde CY24SU06 varsa artık fiziksel dosya mevcut
        report_json_path.write_text(
            json.dumps(data, indent=2, ensure_ascii=False),
            encoding="utf-8"
        )

    # 3. final/ klasörünü hazırla (.pbix kaydı için)
    final_dir = proj_dir / "final"
    final_dir.mkdir(parents=True, exist_ok=True)

    print(f"[ONARILDI] {project_name}: Tema dosyası eklendi ({theme_file.relative_to(root_dir)})")
    return True


def main():
    root_dir = Path(__file__).resolve().parent
    print(f"Power BI Portföy Onarım Betiği Çalıştırılıyor: {root_dir}\n" + "-" * 60)
    fixed_count = 0
    for proj in PROJECTS:
        if fix_project(root_dir, proj):
            fixed_count += 1
    print("-" * 60)
    print(f"Tamamlandı: {fixed_count}/{len(PROJECTS)} proje onarıldı.")
    print("Şimdi Windows Power BI Desktop ile ilgili .pbip dosyalarını açıp .pbix olarak kaydedebilirsiniz.")


if __name__ == "__main__":
    main()