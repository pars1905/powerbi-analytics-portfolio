# Power BI Analytics Portfolio

Bu depo, 12 veri analizi projesinin Power BI kaynak dosyalarını (`*.pbip`), veri tablolarını (`data/`), denetlenebilir analiz çıktılarını (`analysis_evidence/`) ve görsel BI raporlarını içerir.

## Projeler

| Sıra | Proje | Veri/Analiz | Rapor Durumu | 
| ----- | ----- | ----- | ----- | 
| 01 | [01_Makro](https://www.google.com/search?q=01_Makro/) — Türkiye makro göstergeleri | World Bank WDI (2000–2025) | Görsel Rapor & PBIP Modeli Hazır | 
| 02 | [02_Ecommerce](https://www.google.com/search?q=02_Ecommerce/) — E-ticaret satış analizi | UCI Online Retail (38 Ülke) | Görsel Rapor & PBIP Modeli Hazır | 
| 03 | [03_RFM](https://www.google.com/search?q=03_RFM/) — RFM müşteri segmentleri | UCI Online Retail (2011-12-10) | Görsel Rapor & PBIP Modeli Hazır | 
| 04 | [04_SQL_Buyume](https://www.google.com/search?q=04_SQL_Buyume/) — SQL satış büyümesi | UCI Online Retail SQLite (13 Ay) | Görsel Rapor & PBIP Modeli Hazır | 
| 05 | [05_SQL_Retention](https://www.google.com/search?q=05_SQL_Retention/) — SQL kohort ve retention | UCI Online Retail (13 Kohort) | Görsel Rapor & PBIP Modeli Hazır | 
| 06 | [06_SQL_Sepet](https://www.google.com/search?q=06_SQL_Sepet/) — SQL sepet analizi | UCI Online Retail (17,582 Fatura) | Görsel Rapor & PBIP Modeli Hazır | 
| 07 | [07_AB_Donusum](https://www.google.com/search?q=07_AB_Donusum/) — Checkout A/B testi | Sentetik deney (n=14,751/grup) | Görsel Rapor & PBIP Modeli Hazır | 
| 08 | [08_AB_Gelir](https://www.google.com/search?q=08_AB_Gelir/) — Promosyon A/B testi | Sentetik deney (n=15,841/grup) | Görsel Rapor & PBIP Modeli Hazır | 
| 09 | [09_AB_CUPED](https://www.google.com/search?q=09_AB_CUPED/) — CUPED analizi | Sentetik deney (Theta=0.706) | Görsel Rapor & PBIP Modeli Hazır | 
| 10 | [10_Risk_German](https://www.google.com/search?q=10_Risk_German/) — German Credit risk modeli | UCI German Credit (n=1,000) | Görsel Rapor & PBIP Modeli Hazır | 
| 11 | [11_Risk_Taiwan](https://www.google.com/search?q=11_Risk_Taiwan/) — Taiwan kredi riski | UCI Taiwan Default (n=30,000) | Görsel Rapor & PBIP Modeli Hazır | 
| 12 | [12_Risk_Politika](https://www.google.com/search?q=12_Risk_Politika/) — Risk politikası ve stres | Taiwan Model Çıktıları (2 Sayfa) | Görsel Rapor & PBIP Modeli Hazır | 

Her proje klasöründe şu bileşenler bulunur:

* `README.md` ve `dashboard.png`: Klasör içine girildiğinde doğrudan görüntülenen grafikli proje raporu

* `data/`: Aktarıma hazır CSV tabloları

* `analysis_evidence/`: Yöntem (`METHOD.md`) ve sonuçlar (`RESULTS.md`)

* `CHECKS.json`: Beklenen kontrol değerleri

* `.pbip`, `.Report/`, `.SemanticModel/`: Power BI proje ve model tanımı

## 📊 12 Proje Görsel Analitik Raporları ve Grafik Çıktıları

### 01. [01_Makro](https://www.google.com/search?q=01_Makro/) — Türkiye makro göstergeleri

* **Veri Kaynağı:** World Bank WDI (2000–2025)

* **Doğrulanan KPI Özeti (`CHECKS.json` & `RESULTS.md`):** 2025 son yıl: TÜFE %34.88, GSYH büyüme %3.60, işsizlik %8.52 (26 yıllık tam seri).

* **Analitik Karar:** Kurumsal bütçe senaryolarını tek bir makro göstergeye bağlama; nominal satış ile reel büyümeyi ayır.

```
xychart-beta
    title "01_Makro: Turkiye TUFE Enflasyonu ve GSYH Buyumesi (2018-2025, %)"
    x-axis [2018, 2019, 2020, 2021, 2022, 2023, 2024, 2025]
    y-axis "Yillik Oran (%)" 0 --> 80
    bar [16.33, 15.18, 12.28, 19.60, 72.31, 53.86, 58.51, 34.88]
    line [3.00, 0.82, 1.86, 11.81, 5.44, 5.05, 3.33, 3.60]

```

### 02. [02_Ecommerce](https://www.google.com/search?q=02_Ecommerce/) — E-ticaret satış analizi

* **Veri Kaynağı:** UCI Online Retail (38 Ülke)

* **Doğrulanan KPI Özeti (`CHECKS.json` & `RESULTS.md`):** Model satış: 8,911,407.39 GBP (25,900 fatura); Ocak–Kasım 2011 ciro: 9,182,867.74 GBP (17,582 sipariş, AOV 522.29 GBP, UK payı %83.46).

* **Analitik Karar:** Yüksek paylı pazarda operasyon sürekliliğini öncele; küçük pazarlara yatırım kararı için kâr ve edinim maliyeti topla.

```
pie showData
    title 02_Ecommerce: Ocak-Kasim 2011 Ulke Ciro Payi (%)
    "United Kingdom (%83.46)" : 83.46
    "Diger 37 Ulke (%16.54)" : 16.54

```

### 03. [03_RFM](https://www.google.com/search?q=03_RFM/) — RFM müşteri segmentleri

* **Veri Kaynağı:** UCI Online Retail (2011-12-10)

* **Doğrulanan KPI Özeti (`CHECKS.json` & `RESULTS.md`):** 4,339 müşteri (toplam 8,887,208.89 GBP): 633 Champions, 593 At Risk, 63 Can't Lose; 285 geri kazanım pilot adayı.

* **Analitik Karar:** 285 geri kazanım adayında randomize kontrollü bir geri kazanım pilotu tasarla; önceden churn olasılığı iddia etme.

```
xychart-beta
    title "03_RFM: Kritik Musteri Segment Buyuklukleri (Kisi Sayisi)"
    x-axis ["Champions", "At Risk", "Winback Adayi", "Cant Lose"]
    y-axis "Musteri Sayisi" 0 --> 700
    bar [633, 593, 285, 63]

```

### 04. [04_SQL_Buyume](https://www.google.com/search?q=04_SQL_Buyume/) — SQL satış büyümesi

* **Veri Kaynağı:** UCI Online Retail SQLite (13 Ay)

* **Doğrulanan KPI Özeti (`CHECKS.json` & `RESULTS.md`):** 2010-12 – 2011-12 (13 ay) toplam 9,749,138.20 GBP ciro; zirve ay 2011-11 (1,461,756.24 GBP); 261 satır (0.009 sn).

* **Analitik Karar:** Ülke payını aylık değişimle birlikte izle; tek pazar yoğunlaşmasını azaltmak için ülke bazlı kâr ve edinim maliyeti gerekir.

```
xychart-beta
    title "04_SQL_Buyume: Donemsel Ciro Kiyaslamasi (Bin GBP)"
    x-axis ["2011-01 UK Cirosu", "13 Aylik Ortalama", "2011-11 Zirve Ay"]
    y-axis "Ciro (Bin GBP)" 0 --> 1600
    bar [560, 750, 1462]

```

### 05. [05_SQL_Retention](https://www.google.com/search?q=05_SQL_Retention/) — SQL kohort ve retention

* **Veri Kaynağı:** UCI Online Retail (13 Kohort)

* **Doğrulanan KPI Özeti (`CHECKS.json` & `RESULTS.md`):** 13 kohort (min 41 – maks 885 müşteri); genel M1 elde tutma %37.08; 2010-12 M1 %36.61, 2011-01 M1 %22.06, 2011-02 M1 %18.68.

* **Analitik Karar:** Küçük veya düşen kohortlarda edinim kanalı ve stok bulunurluğunu araştır; 2010 Aralık kohortu sol sansürlüdür.

```
xychart-beta
    title "05_SQL_Retention: 1. Ay (M1) Elde Tutma Oranlari (%)"
    x-axis ["2010-12 (n=885)", "2011-01 (n=417)", "2011-02 (n=380)", "Genel M1 (CHECKS)"]
    y-axis "M1 Retention (%)" 0 --> 45
    bar [36.61, 22.06, 18.68, 37.08]

```

### 06. [06_SQL_Sepet](https://www.google.com/search?q=06_SQL_Sepet/) — SQL sepet analizi

* **Veri Kaynağı:** UCI Online Retail (17,582 Fatura)

* **Doğrulanan KPI Özeti (`CHECKS.json` & `RESULTS.md`):** 16,075 çok ürünlü fatura (%91.43); 244,908 benzersiz çift içinden 1,770 aday çift; 22697–22699 çiftinde 692 sipariş, %3.94 support, %75.38 confidence.

* **Analitik Karar:** Yeterli support ve lift gösteren çiftlerde kontrollü çapraz satış deneyi tasarla; lift doğrudan satış artışı değildir.

```
xychart-beta
    title "06_SQL_Sepet: Birliktelik Metrikleri (%)"
    x-axis ["Support (22697-22699)", "Confidence A->B", "Cok Urunlu Sepet Orani"]
    y-axis "Oran (%)" 0 --> 100
    bar [3.94, 75.38, 91.43]

```

### 07. [07_AB_Donusum](https://www.google.com/search?q=07_AB_Donusum/) — Checkout A/B testi

* **Veri Kaynağı:** Sentetik deney (n=14,751/grup)

* **Doğrulanan KPI Özeti (`CHECKS.json` & `RESULTS.md`):** Senaryo kanıtında +1.155 yüzde puan artış (%95 GA \[0.443, 1.868\], p=0.00149, SRM p=0.6166); CHECKS şablon kontrol p=0.1897.

* **Analitik Karar:** İstatistiksel artış mevcuttur; ancak kâr ve hata oranı guardrail verisi doğrulanmadan tam yayına geçilmemelidir.

```
xychart-beta
    title "07_AB_Donusum: Senaryo Kaniti ve %95 Guven Araligi (Yuzde Puan)"
    x-axis ["%95 GA Alt Sinir", "Gozlenen Fark", "%95 GA Ust Sinir", "Hedef MDE"]
    y-axis "Yuzde Puan" 0 --> 2.2
    bar [0.443, 1.155, 1.868, 1.000]

```

### 08. [08_AB_Gelir](https://www.google.com/search?q=08_AB_Gelir/) — Promosyon A/B testi

* **Veri Kaynağı:** Sentetik deney (n=15,841/grup)

* **Doğrulanan KPI Özeti (`CHECKS.json` & `RESULTS.md`):** RPV farkı +0.813 GBP (%95 GA \[0.086, 1.540\]) iken katkı vekili farkı -1.109 GBP (%95 GA \[-1.339, -0.879\]); CHECKS Gate 30 vs 40 p=0.1002.

* **Analitik Karar:** Yayına geçme; RPV artışına rağmen katkı vekili alt sınırı (-1.339 GBP) -0.20 GBP ekonomik guardrail sınırının altındadır.

```
xychart-beta
    title "08_AB_Gelir: RPV Farki ve Katki Vekili %95 Guven Araligi (GBP)"
    x-axis ["RPV Alt", "RPV Farki", "RPV Ust", "Katki Alt", "Katki Farki", "Katki Ust"]
    y-axis "GBP / Kullanici" -1.6 --> 1.8
    bar [0.086, 0.813, 1.540, -1.339, -1.109, -0.879]

```

### 09. [09_AB_CUPED](https://www.google.com/search?q=09_AB_CUPED/) — CUPED analizi

* **Veri Kaynağı:** Sentetik deney (Theta=0.706)

* **Doğrulanan KPI Özeti (`CHECKS.json` & `RESULTS.md`):** CUPED düzeltmeli fark +2.503 GBP (%95 GA \[1.110, 3.896\], n=1,574/grup); tahmin varyansında %61.1 (CHECKS ham->CUPED -%20.04, p=0.0123) azalma.

* **Analitik Karar:** Deney öncesi harcama kovaryatı mevcutsa önceden kayıtlı birincil analiz olarak kullanılmalıdır.

```
xychart-beta
    title "09_AB_CUPED: CUPED Farki ve %95 Guven Araligi (GBP)"
    x-axis ["%95 GA Alt", "CUPED Farki", "%95 GA Ust", "Hedef MDE"]
    y-axis "GBP" 0 --> 4.2
    bar [1.110, 2.503, 3.896, 2.000]

```

### 10. [10_Risk_German](https://www.google.com/search?q=10_Risk_German/) — German Credit risk modeli

* **Veri Kaynağı:** UCI German Credit (n=1,000)

* **Doğrulanan KPI Özeti (`CHECKS.json` & `RESULTS.md`):** 600/200/200 bölünme, %30.0 kötü kredi; Test ROC AUC 0.7990 (CHECKS 0.7891), PR AUC 0.6467, Brier 0.1603 (baz 0.2100), eşik 0.22 (TN=69, FP=71, FN=6, TP=54).

* **Analitik Karar:** Tarihsel ayırma gücü için temel benchmark olarak kullanılmalı; dış zaman doğrulaması olmadan otomatik kredi reddi yapılmamalıdır.

```
xychart-beta
    title "10_Risk_German: Model Performans ve Kalibrasyon Metrikleri"
    x-axis ["Test ROC AUC", "CHECKS AUC", "PR AUC", "Model Brier", "Baz Brier"]
    y-axis "Skor" 0 --> 0.90
    bar [0.7990, 0.7891, 0.6467, 0.1603, 0.2100]

```

### 11. [11_Risk_Taiwan](https://www.google.com/search?q=11_Risk_Taiwan/) — Taiwan kredi riski

* **Veri Kaynağı:** UCI Taiwan Default (n=30,000)

* **Doğrulanan KPI Özeti (`CHECKS.json` & `RESULTS.md`):** 18k/6k/6k bölünme, %22.12 temerrüt (6,636 kişi); Test ROC AUC 0.7618 (CHECKS 0.7713), PR AUC 0.5275, Brier 0.1381 (baz 0.1723), eşik 0.17 (TN=3330, FP=1343, FN=455, TP=872).

* **Analitik Karar:** Tarihsel ayırma gücü için benchmark olarak kullanılmalı; dış zaman testi, kalibrasyon ve kayıp maliyeti doğrulanmalıdır.

```
xychart-beta
    title "11_Risk_Taiwan: Model Performans ve Kalibrasyon Metrikleri"
    x-axis ["Test ROC AUC", "CHECKS AUC", "PR AUC", "Model Brier", "Baz Brier"]
    y-axis "Skor" 0 --> 0.85
    bar [0.7618, 0.7713, 0.5275, 0.1381, 0.1723]

```

### 12. [12_Risk_Politika](https://www.google.com/search?q=12_Risk_Politika/) — Risk politikası ve stres

* **Veri Kaynağı:** Taiwan Model Çıktıları (2 Sayfa)

* **Doğrulanan KPI Özeti (`CHECKS.json` & `RESULTS.md`):** 18k/3k/3k/6k bölünme; seçilen eşik 0.17 ile %38.07 inceleme payı ve 0.5985 müşteri başı maliyet vekili (incelemesiz: 1.1058, tümü: 0.7788). Stres altında ort. PD: 0.2180 → 0.3491.

* **Analitik Karar:** Gerçek FN/FP maliyetleri ve operasyonel inceleme kapasitesi doğrulanmadan bu eşik üretime taşınmamalıdır.

```
xychart-beta
    title "12_Risk_Politika: Karar Politikalarina Gore Musteri Basi Maliyet Vekili"
    x-axis ["Hic Inceleme Yok", "Herkesi Incele", "Secilen Esik (0.17)"]
    y-axis "Maliyet Vekili" 0 --> 1.20
    bar [1.1058, 0.7788, 0.5985]

```